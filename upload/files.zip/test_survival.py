"""
test_survival.py
================
Smoke tests for survival.py.
Runs against real Gemini API — set GEMINI_API_KEY before running.

Usage:
    GEMINI_API_KEY=your_key python test_survival.py
"""

import os
import sys
import json
import math
import tempfile
import unittest

TMP = tempfile.mkdtemp()

from survival import (
    SurvivalConfig,
    SurvivalEngine,
    DriftTracker,
    _survival_scalar,
    _amplification,
    _decision,
    _cosine_sim,
    _jaccard_sim,
)


# ─────────────────────────────────────────────────────────────────────────────
# Unit tests (no API calls)
# ─────────────────────────────────────────────────────────────────────────────

class TestSurvivalMath(unittest.TestCase):

    def setUp(self):
        self.cfg = SurvivalConfig(epsilon_u=1e-6, lambda1=1.0, lambda2=1.0,
                                  tau_high=0.70, tau_low=0.35)

    def test_survival_scalar_bounded(self):
        for kappa in [0.0, 0.01, 0.5, 0.99, 1.0]:
            for dL in [0.0, 0.1, 0.5]:
                for dG in [0.0, 0.1, 0.5]:
                    S = _survival_scalar(kappa, dL, dG, self.cfg)
                    self.assertGreaterEqual(S, 0.0, f"S<0 with κ={kappa}")
                    self.assertLessEqual(S, 1.0 + 1e-9, f"S>1 with κ={kappa}")

    def test_survival_scalar_high_kappa(self):
        """When κ is high and uncertainty is low, S should approach 1."""
        S = _survival_scalar(1.0, 0.0, 0.0, self.cfg)
        self.assertGreater(S, 0.99)

    def test_survival_scalar_zero_kappa(self):
        """When κ=0, S should be near 0."""
        S = _survival_scalar(0.0, 0.5, 0.5, self.cfg)
        self.assertAlmostEqual(S, 0.0, places=5)

    def test_amplification_spikes_at_zero_kappa(self):
        A = _amplification(0.0, 1e-6)
        self.assertGreater(A, 1e5)

    def test_amplification_small_at_high_kappa(self):
        A = _amplification(1.0, 1e-6)
        self.assertAlmostEqual(A, 1.0, places=1)

    def test_decision_thresholds(self):
        self.assertEqual(_decision(0.8, self.cfg), "accept")
        self.assertEqual(_decision(0.5, self.cfg), "review")
        self.assertEqual(_decision(0.2, self.cfg), "reject")
        # Boundary — tau_high
        self.assertEqual(_decision(0.70, self.cfg), "review")   # not strictly >
        self.assertEqual(_decision(0.71, self.cfg), "accept")

    def test_cosine_sim_identical(self):
        v = [1.0, 0.0, 0.5]
        self.assertAlmostEqual(_cosine_sim(v, v), 1.0, places=5)

    def test_cosine_sim_orthogonal(self):
        self.assertAlmostEqual(_cosine_sim([1.0, 0.0], [0.0, 1.0]), 0.0, places=5)

    def test_jaccard_identical(self):
        self.assertAlmostEqual(_jaccard_sim("hello world", "hello world"), 1.0)

    def test_jaccard_disjoint(self):
        self.assertAlmostEqual(_jaccard_sim("hello", "goodbye"), 0.0)


class TestDriftTracker(unittest.TestCase):

    def setUp(self):
        import os
        self.path = os.path.join(TMP, "test_drift.jsonl")

    def tearDown(self):
        import os
        if os.path.exists(self.path):
            os.remove(self.path)

    def test_first_observation_no_sdot(self):
        dt = DriftTracker(self.path, window=10)
        S_dot, warn = dt.update("2025-01-01T00:00:00Z", 0.8)
        self.assertIsNone(S_dot)
        self.assertFalse(warn)

    def test_sdot_computed_correctly(self):
        dt = DriftTracker(self.path, window=10)
        dt.update("t1", 0.8)
        S_dot, _ = dt.update("t2", 0.6)
        self.assertAlmostEqual(S_dot, -0.2, places=5)

    def test_drift_warning_fires(self):
        dt = DriftTracker(self.path, window=10)
        dt.update("t1", 0.8)
        _, warn = dt.update("t2", 0.6)   # Δ = -0.2, threshold is -0.15
        self.assertTrue(warn)

    def test_no_drift_warning_on_small_drop(self):
        dt = DriftTracker(self.path, window=10)
        dt.update("t1", 0.8)
        _, warn = dt.update("t2", 0.75)  # Δ = -0.05, below threshold
        self.assertFalse(warn)

    def test_window_capped(self):
        dt = DriftTracker(self.path, window=3)
        for i in range(10):
            dt.update(f"t{i}", 0.5)
        self.assertLessEqual(len(dt._history), 3)

    def test_trend_summary(self):
        dt = DriftTracker(self.path, window=10)
        # Use large drops so mean_drift < -0.15 (declining threshold)
        for v in [0.9, 0.7, 0.5, 0.3]:
            dt.update("t", v)
        trend = dt.trend()
        self.assertEqual(trend["n"], 4)
        self.assertLess(trend["mean_drift"], 0.0)   # declining
        self.assertTrue(trend["declining"])


# ─────────────────────────────────────────────────────────────────────────────
# Integration test (requires GEMINI_API_KEY)
# ─────────────────────────────────────────────────────────────────────────────

class TestSurvivalEngineIntegration(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.api_key = os.environ.get("GEMINI_API_KEY", "")
        cls.skip = not cls.api_key
        if not cls.skip:
            cfg = SurvivalConfig(
                gemini_api_key=cls.api_key,
                n_perturbations=3,     # minimal calls for speed
                n_contexts=2,
                survival_log_path=os.path.join(TMP, "test_survival_log.jsonl"),
                drift_history_path=os.path.join(TMP, "test_drift_history.jsonl"),
            )
            cls.engine = SurvivalEngine(cfg)

    def _skip_if_no_key(self):
        if self.skip:
            self.skipTest("GEMINI_API_KEY not set — skipping integration tests")

    def test_evaluate_returns_valid_result(self):
        self._skip_if_no_key()
        result = self.engine.evaluate("What is 2 + 2?")
        self.assertIsNotNone(result.query_id)
        self.assertGreaterEqual(result.S, 0.0)
        self.assertLessEqual(result.S, 1.0)
        self.assertGreater(result.A, 0.0)
        self.assertIn(result.decision, ["accept", "review", "reject"])
        self.assertGreater(result.latency_ms, 0)

    def test_kappa_bounded(self):
        self._skip_if_no_key()
        result = self.engine.evaluate("Explain gravity briefly.")
        self.assertGreaterEqual(result.kappa, 0.0)
        self.assertLessEqual(result.kappa, 1.0)

    def test_drift_populated_after_two_calls(self):
        self._skip_if_no_key()
        r1 = self.engine.evaluate("What color is the sky?")
        r2 = self.engine.evaluate("What color is the ocean?")
        self.assertIsNone(r1.S_dot if len(self.engine.drift_summary()["recent"]) <= 1 else None)
        # At least r2 should have a drift value
        summary = self.engine.drift_summary()
        self.assertGreaterEqual(summary["trend"]["n"], 2)

    def test_log_file_written(self):
        self._skip_if_no_key()
        import os
        self.engine.evaluate("Test log write.")
        log_path = self.engine.cfg.survival_log_path
        self.assertTrue(os.path.exists(log_path))
        with open(log_path) as f:
            lines = [l for l in f if l.strip()]
        self.assertGreater(len(lines), 0)
        rec = json.loads(lines[-1])
        self.assertIn("S", rec)
        self.assertIn("decision", rec)
        self.assertIn("kappa", rec)


if __name__ == "__main__":
    print("─" * 60)
    print("eval-control: Survival Scalar Test Suite")
    print("─" * 60)
    if not os.environ.get("GEMINI_API_KEY"):
        print("⚠  GEMINI_API_KEY not set — integration tests will be skipped")
        print("   Unit tests (no API calls) will run.")
    print()
    unittest.main(verbosity=2)
