"""
survival_sdk.py — Zero-dependency client for survival scalar endpoints
=======================================================================
Mirrors the pattern of the existing sdk.py (stdlib urllib only).
Can be used standalone or composed with the existing SDK client.

Usage:
    from survival_sdk import SurvivalClient

    client = SurvivalClient(
        base_url="http://localhost:8000",
        api_key="your-key"
    )

    result = client.evaluate("Explain quantum entanglement")
    print(result["S"], result["decision"])

    drift = client.drift(n=20)
    print(drift["trend"])
"""

import json
import urllib.request
import urllib.error
from typing import Optional


class SurvivalClient:
    """
    Thin client for the /survival-* endpoints.
    Zero external dependencies — pure stdlib.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: Optional[str] = None,
        timeout: int = 120,    # survival eval can be slow (many Gemini calls)
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["X-API-Key"] = self.api_key
        return h

    def _post(self, path: str, body: dict) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, headers=self._headers(), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            raise RuntimeError(f"HTTP {e.code}: {body}") from e

    def _get(self, path: str, params: Optional[dict] = None) -> dict:
        url = f"{self.base_url}{path}"
        if params:
            qs = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{qs}"
        req = urllib.request.Request(url, headers=self._headers(), method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            raise RuntimeError(f"HTTP {e.code}: {body}") from e

    # ── Public API ───────────────────────────────────────────────────

    def evaluate(self, prompt: str, query_id: Optional[str] = None) -> dict:
        """
        POST /survival-eval

        Returns full SurvivalResult dict including:
          S, A, decision, kappa, delta_L, delta_G, S_dot, drift_warning, ...
        """
        body = {"prompt": prompt}
        if query_id:
            body["query_id"] = query_id
        return self._post("/survival-eval", body)

    def drift(self, n: int = 20) -> dict:
        """
        GET /survival-drift

        Returns {"recent": [...], "trend": {...}}
        trend includes: mean_S, mean_drift, min_S, max_S, declining
        """
        return self._get("/survival-drift", {"n": n})

    def log(self, n: int = 20) -> list[dict]:
        """GET /survival-log — last n evaluation records."""
        resp = self._get("/survival-log", {"n": n})
        return resp.get("evaluations", [])

    def health(self) -> dict:
        """GET /survival-health — key configured, model, thresholds."""
        return self._get("/survival-health")


# ─────────────────────────────────────────────────────────────────────────────
# Quick CLI smoke test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
    key = sys.argv[2] if len(sys.argv) > 2 else None

    print(f"Connecting to {url} …")
    client = SurvivalClient(base_url=url, api_key=key)

    print("\n── Health ──")
    try:
        h = client.health()
        print(json.dumps(h, indent=2))
    except Exception as e:
        print(f"Health check failed: {e}")
        sys.exit(1)

    print("\n── Evaluate ──")
    prompt = "What are the risks of deploying AI in high-stakes environments?"
    print(f"Prompt: {prompt!r}")
    try:
        result = client.evaluate(prompt)
        print(f"  S        = {result['S']:.4f}")
        print(f"  κ        = {result['kappa']:.4f}")
        print(f"  ΔL       = {result['delta_L']:.4f}")
        print(f"  ΔG       = {result['delta_G']:.4f}")
        print(f"  A        = {result['A']:.2f}")
        print(f"  decision = {result['decision'].upper()}")
        print(f"  Ṡ(t)     = {result['S_dot']}")
        print(f"  latency  = {result['latency_ms']}ms")
        if result["drift_warning"]:
            print("  ⚠  DRIFT WARNING")
    except Exception as e:
        print(f"Evaluate failed: {e}")

    print("\n── Drift ──")
    try:
        d = client.drift(n=10)
        print(json.dumps(d["trend"], indent=2))
    except Exception as e:
        print(f"Drift failed: {e}")
