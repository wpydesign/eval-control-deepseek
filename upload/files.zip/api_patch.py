"""
api_patch.py
============
Apply this as a literal patch to api.py — adds survival endpoints
without touching any v4.3 frozen logic.

HOW TO APPLY
─────────────
In your existing api.py, find the line that reads:

    app = FastAPI(...)

(or wherever the FastAPI app is instantiated).

Add these two lines IMMEDIATELY AFTER it:

    from survival_router import survival_router
    app.include_router(survival_router)

That's it. Nothing else changes.

───────────────────────────────────────────────
EXACT DIFF (apply manually or with patch tool)
───────────────────────────────────────────────

Locate in api.py:

    app = FastAPI(
        title="eval-control",
        ...
    )

Add after it:

    # ── Survival scalar layer (separate module, v4.3 untouched) ──
    from survival_router import survival_router          # noqa: E402
    app.include_router(survival_router)

───────────────────────────────────────────────
COPY survival.py AND survival_router.py
into the same directory as api.py before applying.
───────────────────────────────────────────────
"""

# This file is documentation only.
# The actual import is two lines; paste them into api.py as described above.
