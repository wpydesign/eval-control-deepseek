# eval-control: Survival Scalar Layer

Standalone extension to the existing eval-control v4.3 system.
**Does not touch core.py, shadow_mode.py, or any frozen formula.**

---

## What this adds

```
S(x) = κ(x) / (κ(x) + λ₁·ΔL(x) + λ₂·ΔG(x) + ε_u)
```

| Symbol | Meaning | How computed |
|--------|---------|--------------|
| `κ(x)` | Consistency under perturbation | Average cosine sim of Gemini responses to `n` prompt variants |
| `ΔL(x)` | Local uncertainty | Variance of similarity scores across perturbations |
| `ΔG(x)` | Global inconsistency | Avg pairwise dissimilarity across `n` context framings |
| `S(x)` | Survival scalar ∈ [0,1] | Formula above |
| `A(x)` | Amplification / brittleness | `1 / (κ + ε_u)` — spikes when κ → 0 |
| `Ṡ(t)` | Drift | `S(t) - S(t-1)` — early warning when `Ṡ ≪ 0` |

Decision gate:
```
S > τ_h (0.70)  → accept
τ_l < S ≤ τ_h  → review
S ≤ τ_l (0.35)  → reject
```

---

## Files

| File | Purpose |
|------|---------|
| `survival.py` | Core math — all terms, drift tracker, engine |
| `survival_router.py` | FastAPI router — mounts 4 new endpoints |
| `survival_sdk.py` | Zero-dep Python client (mirrors sdk.py pattern) |
| `test_survival.py` | Unit tests (no API) + integration tests |
| `api_patch.py` | Exactly what to add to api.py (2 lines) |
| `docker-compose.survival.yml` | Overlay — adds env vars and volume |

---

## Installation

### 1. Copy files
```bash
cp survival.py survival_router.py survival_sdk.py /path/to/eval-control/
```

### 2. Patch api.py (2 lines only)
Find the FastAPI app instantiation in `api.py`:
```python
app = FastAPI(title="eval-control", ...)
```

Add immediately after:
```python
from survival_router import survival_router
app.include_router(survival_router)
```

### 3. Set environment variable
```bash
export GEMINI_API_KEY=your_key_here
```

Or in `.env`:
```
GEMINI_API_KEY=your_key_here
```

### 4. Run with overlay
```bash
docker-compose -f docker-compose.yml -f docker-compose.survival.yml up
```

---

## API

### `POST /survival-eval`
```json
{
  "prompt": "Your AI query here",
  "query_id": "optional-stable-id"
}
```
Response includes `S`, `A`, `decision`, `kappa`, `delta_L`, `delta_G`, `S_dot`, `drift_warning`.

### `GET /survival-drift?n=20`
Returns `recent` S(t) history and `trend` statistics.

### `GET /survival-log?n=20`
Returns last n evaluation records from `survival_log.jsonl`.

### `GET /survival-health`
Returns key status, model, thresholds.

---

## Tuning (environment variables)

| Variable | Default | Meaning |
|----------|---------|---------|
| `SURVIVAL_LAMBDA1` | `1.0` | Weight on ΔL |
| `SURVIVAL_LAMBDA2` | `1.0` | Weight on ΔG |
| `SURVIVAL_TAU_HIGH` | `0.70` | Accept threshold |
| `SURVIVAL_TAU_LOW` | `0.35` | Reject threshold |
| `SURVIVAL_N_PERTURB` | `5` | Perturbation samples (lower = faster/cheaper) |
| `SURVIVAL_N_CONTEXTS` | `3` | Context samples |
| `GEMINI_MODEL` | `gemini-2.0-flash` | Gemini model |

---

## Running tests
```bash
# Unit tests only (no API calls):
python test_survival.py

# Full integration tests:
GEMINI_API_KEY=your_key python test_survival.py
```

---

## What is NOT changed

- `core.py` — untouched
- `shadow_mode.py` — untouched
- `outcome_capture.py` — untouched
- `api.py` — 2-line addition only, no formula or logic changes
- All v4.3 frozen thresholds — untouched
