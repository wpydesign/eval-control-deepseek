"""
survival_router.py — FastAPI router for survival scalar endpoints
=================================================================
Drop-in addition to the existing api.py. Never modifies it.

Mount in api.py with ONE line:
    from survival_router import survival_router
    app.include_router(survival_router, prefix="", tags=["survival"])

Endpoints added:
    POST /survival-eval    — run S(x) on a prompt
    GET  /survival-drift   — drift history + trend
    GET  /survival-log     — recent evaluation records
    GET  /survival-health  — lightweight health check (Gemini reachability)
"""

import os
import time
import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Header, Query
from pydantic import BaseModel, Field

from survival import SurvivalEngine, SurvivalConfig, SurvivalResult

logger = logging.getLogger("survival_router")

# ─────────────────────────────────────────────
# Auth — mirrors existing api.py pattern
# ─────────────────────────────────────────────

def _check_auth(x_api_key: Optional[str]):
    allowed = set(
        k.strip()
        for k in os.environ.get("EVAL_CONTROL_API_KEYS", "").split(",")
        if k.strip()
    )
    if allowed and x_api_key not in allowed:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


# ─────────────────────────────────────────────
# Singleton engine — built from env vars
# ─────────────────────────────────────────────

def _build_engine() -> SurvivalEngine:
    cfg = SurvivalConfig(
        gemini_api_key=os.environ.get("GEMINI_API_KEY", ""),
        gemini_model=os.environ.get("GEMINI_MODEL", "gemini-2.0-flash"),
        lambda1=float(os.environ.get("SURVIVAL_LAMBDA1", "1.0")),
        lambda2=float(os.environ.get("SURVIVAL_LAMBDA2", "1.0")),
        epsilon_u=float(os.environ.get("SURVIVAL_EPSILON_U", "1e-6")),
        tau_high=float(os.environ.get("SURVIVAL_TAU_HIGH", "0.70")),
        tau_low=float(os.environ.get("SURVIVAL_TAU_LOW", "0.35")),
        n_perturbations=int(os.environ.get("SURVIVAL_N_PERTURB", "5")),
        n_contexts=int(os.environ.get("SURVIVAL_N_CONTEXTS", "3")),
        survival_log_path=os.environ.get("SURVIVAL_LOG_PATH", "survival_log.jsonl"),
        drift_history_path=os.environ.get("DRIFT_HISTORY_PATH", "drift_history.jsonl"),
        drift_window=int(os.environ.get("DRIFT_WINDOW", "50")),
    )
    return SurvivalEngine(cfg)


_engine: Optional[SurvivalEngine] = None


def get_engine() -> SurvivalEngine:
    global _engine
    if _engine is None:
        _engine = _build_engine()
    return _engine


# ─────────────────────────────────────────────
# Pydantic schemas
# ─────────────────────────────────────────────

class SurvivalEvalRequest(BaseModel):
    prompt: str = Field(..., description="The AI prompt / query to evaluate")
    query_id: Optional[str] = Field(
        None,
        description="Optional stable ID. Auto-generated if omitted."
    )


class SurvivalEvalResponse(BaseModel):
    query_id: str
    prompt: str
    baseline_response: str
    kappa: float
    delta_L: float
    delta_G: float
    S: float
    A: float
    decision: str                # "accept" | "review" | "reject"
    S_dot: Optional[float]       # drift Ṡ(t), None on first call
    drift_warning: bool
    timestamp: str
    latency_ms: float
    config_snapshot: dict

    @classmethod
    def from_result(cls, r: SurvivalResult) -> "SurvivalEvalResponse":
        return cls(**r.to_dict())


class DriftResponse(BaseModel):
    recent: list[dict]
    trend: dict


# ─────────────────────────────────────────────
# Router
# ─────────────────────────────────────────────

survival_router = APIRouter()


@survival_router.post(
    "/survival-eval",
    response_model=SurvivalEvalResponse,
    summary="Run survival scalar S(x) on a prompt",
    description=(
        "Computes κ, ΔL, ΔG, S, A and returns an accept/review/reject decision. "
        "Makes real Gemini API calls. Results logged to survival_log.jsonl."
    ),
)
async def survival_eval(
    body: SurvivalEvalRequest,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
):
    _check_auth(x_api_key)
    if not body.prompt.strip():
        raise HTTPException(status_code=422, detail="prompt must not be empty")

    engine = get_engine()
    if not engine.cfg.gemini_api_key:
        raise HTTPException(
            status_code=503,
            detail="GEMINI_API_KEY not configured on server"
        )

    try:
        result = engine.evaluate(body.prompt.strip(), query_id=body.query_id)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=f"Gemini API error: {exc}") from exc
    except Exception as exc:
        logger.exception("Unexpected error in survival_eval")
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return SurvivalEvalResponse.from_result(result)


@survival_router.get(
    "/survival-drift",
    response_model=DriftResponse,
    summary="Drift history and trend for S(t)",
    description=(
        "Returns recent S(t) values and trend statistics. "
        "Ṡ(t) = S(t) − S(t−1). Negative trend signals drift toward failure."
    ),
)
async def survival_drift(
    n: int = Query(20, ge=1, le=200, description="Number of recent points to return"),
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
):
    _check_auth(x_api_key)
    engine = get_engine()
    return engine.drift_summary(n=n)


@survival_router.get(
    "/survival-log",
    summary="Recent survival evaluations",
    description="Returns the last n records from survival_log.jsonl.",
)
async def survival_log_recent(
    n: int = Query(20, ge=1, le=500, description="Number of recent evaluations to return"),
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
):
    _check_auth(x_api_key)
    engine = get_engine()
    return {"evaluations": engine.recent_evaluations(n=n)}


@survival_router.get(
    "/survival-health",
    summary="Health check: Gemini reachability + config",
)
async def survival_health():
    engine = get_engine()
    has_key = bool(engine.cfg.gemini_api_key)
    return {
        "status": "ok" if has_key else "degraded",
        "gemini_key_set": has_key,
        "model": engine.cfg.gemini_model,
        "thresholds": {
            "tau_high": engine.cfg.tau_high,
            "tau_low": engine.cfg.tau_low,
        },
        "weights": {
            "lambda1": engine.cfg.lambda1,
            "lambda2": engine.cfg.lambda2,
            "epsilon_u": engine.cfg.epsilon_u,
        },
        "sampling": {
            "n_perturbations": engine.cfg.n_perturbations,
            "n_contexts": engine.cfg.n_contexts,
        },
    }
