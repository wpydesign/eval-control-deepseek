"""
survival.py — Survival Scalar S(x) Layer
=========================================
Standalone module. Does NOT touch core.py, shadow_mode.py, or any v4.3 frozen logic.

Math implemented:
  κ(x)  = E_δ[ sim(f(x), f(x+δ)) ]          consistency under perturbation
  ΔL(x) = Var( f(x+δ) )                       local uncertainty
  ΔG(x) = E_{c1,c2}[ 1 - sim(f(x|c1), f(x|c2)) ]  global inconsistency
  S(x)  = κ / (κ + λ₁·ΔL + λ₂·ΔG + ε_u)    survival scalar ∈ [0,1]
  A(x)  = 1 / (κ + ε_u)                       amplification / brittleness
  Ṡ(t)  = S(t) − S(t−1)                       drift signal
"""

import os
import json
import time
import math
import hashlib
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field, asdict

import urllib.request
import urllib.error

logger = logging.getLogger("survival")

# ─────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────

@dataclass
class SurvivalConfig:
    # Formula weights — expose all as configurable
    lambda1: float = 1.0          # weight on ΔL (local uncertainty)
    lambda2: float = 1.0          # weight on ΔG (global inconsistency)
    epsilon_u: float = 1e-6       # numerical stability floor

    # Decision thresholds
    tau_high: float = 0.70        # accept above this
    tau_low: float = 0.35         # reject below this (review in between)

    # Perturbation sampling
    n_perturbations: int = 5      # how many δ samples for κ and ΔL
    n_contexts: int = 3           # how many context framings for ΔG

    # Gemini
    gemini_api_key: str = field(
        default_factory=lambda: os.environ.get("GEMINI_API_KEY", "")
    )
    gemini_model: str = "gemini-2.0-flash"
    gemini_timeout: int = 20

    # Storage
    survival_log_path: str = "survival_log.jsonl"
    drift_history_path: str = "drift_history.jsonl"

    # History window for drift
    drift_window: int = 50


# ─────────────────────────────────────────────
# Perturbation strategies
# ─────────────────────────────────────────────

PERTURBATION_TEMPLATES = [
    "{prompt}",                                          # original (baseline)
    "Please answer the following: {prompt}",
    "In plain language, {prompt}",
    "Think step by step: {prompt}",
    "Be concise. {prompt}",
    "Provide a detailed answer: {prompt}",
]

CONTEXT_TEMPLATES = [
    "{prompt}",
    "As a domain expert, answer: {prompt}",
    "From a practical standpoint: {prompt}",
    "Considering first principles: {prompt}",
    "Give a high-level overview: {prompt}",
]


def _perturb(prompt: str, n: int) -> list[str]:
    """Return n perturbed variants of prompt (including the original)."""
    variants = [PERTURBATION_TEMPLATES[i % len(PERTURBATION_TEMPLATES)].format(prompt=prompt)
                for i in range(n)]
    return variants


def _contextualize(prompt: str, n: int) -> list[str]:
    """Return n context-framed variants of prompt."""
    variants = [CONTEXT_TEMPLATES[i % len(CONTEXT_TEMPLATES)].format(prompt=prompt)
                for i in range(n)]
    return variants


# ─────────────────────────────────────────────
# Gemini API client (stdlib only, no deps)
# ─────────────────────────────────────────────

class GeminiClient:
    BASE = "https://generativelanguage.googleapis.com/v1beta/models"

    def __init__(self, api_key: str, model: str, timeout: int):
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    def generate(self, prompt: str) -> str:
        """Call Gemini generateContent. Returns text string."""
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not set")

        url = f"{self.BASE}/{self.model}:generateContent"
        payload = json.dumps({
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.0,   # deterministic for consistency measurement
                "maxOutputTokens": 512,
            }
        }).encode()

        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-goog-api-key": self.api_key,
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = json.loads(resp.read().decode())
                return body["candidates"][0]["content"]["parts"][0]["text"]
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            raise RuntimeError(f"Gemini HTTP {e.code}: {body}") from e

    def embed(self, text: str) -> list[float]:
        """Call Gemini text embedding. Returns vector."""
        url = f"{self.BASE}/text-embedding-004:embedContent"
        payload = json.dumps({
            "model": "models/text-embedding-004",
            "content": {"parts": [{"text": text[:2000]}]}   # truncate for speed
        }).encode()

        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-goog-api-key": self.api_key,
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = json.loads(resp.read().decode())
                return body["embedding"]["values"]
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            raise RuntimeError(f"Gemini embed HTTP {e.code}: {body}") from e


# ─────────────────────────────────────────────
# Similarity functions
# ─────────────────────────────────────────────

def _cosine_sim(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _jaccard_sim(a: str, b: str) -> float:
    """Token-level Jaccard similarity — cheap fallback when embeddings fail."""
    set_a = set(a.lower().split())
    set_b = set(b.lower().split())
    if not set_a and not set_b:
        return 1.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def _sim(text_a: str, text_b: str, vec_a: Optional[list[float]], vec_b: Optional[list[float]]) -> float:
    """Use cosine if vectors available, else Jaccard."""
    if vec_a and vec_b:
        return _cosine_sim(vec_a, vec_b)
    return _jaccard_sim(text_a, text_b)


# ─────────────────────────────────────────────
# Core metric computations
# ─────────────────────────────────────────────

def _compute_kappa_and_delta_L(
    prompt: str,
    baseline_text: str,
    baseline_vec: Optional[list[float]],
    client: GeminiClient,
    cfg: SurvivalConfig,
) -> tuple[float, float]:
    """
    κ(x) = E_δ[ sim(f(x), f(x+δ)) ]
    ΔL(x) = Var over perturbed outputs (measured as 1 - mean_sim, proxy for spread)

    Returns (kappa, delta_L).
    """
    perturbed = _perturb(prompt, cfg.n_perturbations)[1:]  # skip original (index 0)
    sims = []

    for p in perturbed:
        try:
            resp_text = client.generate(p)
            try:
                resp_vec = client.embed(resp_text)
            except Exception:
                resp_vec = None

            s = _sim(baseline_text, resp_text, baseline_vec, resp_vec)
            sims.append(s)
        except Exception as exc:
            logger.warning("Perturbation call failed: %s", exc)
            sims.append(0.0)   # treat failure as maximum inconsistency

    if not sims:
        return 0.0, 1.0

    kappa = sum(sims) / len(sims)

    # ΔL = variance of similarity scores (spread of outputs)
    mean = kappa
    variance = sum((s - mean) ** 2 for s in sims) / len(sims)

    return kappa, variance


def _compute_delta_G(
    prompt: str,
    client: GeminiClient,
    cfg: SurvivalConfig,
) -> float:
    """
    ΔG(x) = E_{c1,c2}[ 1 - sim(f(x|c1), f(x|c2)) ]

    Generates outputs under different context framings and measures
    how much they contradict each other.
    """
    contexts = _contextualize(prompt, cfg.n_contexts)
    responses_text = []
    responses_vec = []

    for c in contexts:
        try:
            t = client.generate(c)
            responses_text.append(t)
            try:
                v = client.embed(t)
                responses_vec.append(v)
            except Exception:
                responses_vec.append(None)
        except Exception as exc:
            logger.warning("Context call failed: %s", exc)
            responses_text.append("")
            responses_vec.append(None)

    # All pairwise (c1, c2) inconsistencies
    inconsistencies = []
    n = len(responses_text)
    for i in range(n):
        for j in range(i + 1, n):
            s = _sim(
                responses_text[i], responses_text[j],
                responses_vec[i], responses_vec[j]
            )
            inconsistencies.append(1.0 - s)

    if not inconsistencies:
        return 0.0

    return sum(inconsistencies) / len(inconsistencies)


# ─────────────────────────────────────────────
# Survival scalar
# ─────────────────────────────────────────────

def _survival_scalar(
    kappa: float,
    delta_L: float,
    delta_G: float,
    cfg: SurvivalConfig,
) -> float:
    """
    S(x) = κ / (κ + λ₁·ΔL + λ₂·ΔG + ε_u)
    Bounded in [0, 1]. Stable under scaling.
    """
    numerator = kappa
    denominator = kappa + cfg.lambda1 * delta_L + cfg.lambda2 * delta_G + cfg.epsilon_u
    return numerator / denominator


def _amplification(kappa: float, epsilon_u: float) -> float:
    """
    A(x) = 1 / (κ + ε_u)
    Spikes when κ → 0 (brittle, adversarial, edge-of-failure).
    """
    return 1.0 / (kappa + epsilon_u)


def _decision(S: float, cfg: SurvivalConfig) -> str:
    if S > cfg.tau_high:
        return "accept"
    elif S > cfg.tau_low:
        return "review"
    else:
        return "reject"


# ─────────────────────────────────────────────
# Result dataclass
# ─────────────────────────────────────────────

@dataclass
class SurvivalResult:
    query_id: str
    prompt: str
    baseline_response: str
    kappa: float
    delta_L: float
    delta_G: float
    S: float
    A: float
    decision: str
    S_dot: Optional[float]      # drift Ṡ(t), None if first observation
    drift_warning: bool
    timestamp: str
    config_snapshot: dict
    latency_ms: float

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────
# Drift tracker (thread-safe)
# ─────────────────────────────────────────────

class DriftTracker:
    """
    Maintains a rolling window of S(t) values.
    Computes Ṡ(t) = S(t) - S(t-1) and flags warnings.
    """
    _DRIFT_WARN_THRESHOLD = -0.15   # Ṡ ≪ 0 → drifting toward failure

    def __init__(self, path: str, window: int):
        self._path = path
        self._window = window
        self._lock = threading.Lock()
        self._history: list[tuple[str, float]] = []  # (timestamp, S)
        self._load()

    def _load(self):
        p = Path(self._path)
        if not p.exists():
            return
        with open(p) as f:
            for line in f:
                try:
                    rec = json.loads(line)
                    self._history.append((rec["timestamp"], rec["S"]))
                except Exception:
                    pass
        # Keep only window
        self._history = self._history[-self._window:]

    def update(self, timestamp: str, S: float) -> tuple[Optional[float], bool]:
        """
        Returns (S_dot, drift_warning).
        S_dot is None on first observation.
        """
        with self._lock:
            S_dot = None
            if self._history:
                S_dot = S - self._history[-1][1]

            self._history.append((timestamp, S))
            if len(self._history) > self._window:
                self._history.pop(0)

            # Persist
            with open(self._path, "a") as f:
                f.write(json.dumps({"timestamp": timestamp, "S": S}) + "\n")

            warn = (S_dot is not None) and (S_dot < self._DRIFT_WARN_THRESHOLD)
            return S_dot, warn

    def recent(self, n: int = 20) -> list[dict]:
        with self._lock:
            return [{"timestamp": ts, "S": s} for ts, s in self._history[-n:]]

    def trend(self) -> dict:
        """Return summary statistics over the stored window."""
        with self._lock:
            if not self._history:
                return {"n": 0}
            values = [s for _, s in self._history]
            n = len(values)
            mean = sum(values) / n
            if n > 1:
                deltas = [values[i] - values[i - 1] for i in range(1, n)]
                mean_drift = sum(deltas) / len(deltas)
                min_v = min(values)
                max_v = max(values)
            else:
                mean_drift = 0.0
                min_v = max_v = values[0]
            return {
                "n": n,
                "mean_S": round(mean, 4),
                "mean_drift": round(mean_drift, 4),
                "min_S": round(min_v, 4),
                "max_S": round(max_v, 4),
                "declining": mean_drift < self._DRIFT_WARN_THRESHOLD,
            }


# ─────────────────────────────────────────────
# Survival Engine — main entry point
# ─────────────────────────────────────────────

class SurvivalEngine:
    """
    Orchestrates the full S(x) computation pipeline.
    Thread-safe. Logs every result to survival_log.jsonl.
    """

    def __init__(self, cfg: Optional[SurvivalConfig] = None):
        self.cfg = cfg or SurvivalConfig()
        self._client = GeminiClient(
            api_key=self.cfg.gemini_api_key,
            model=self.cfg.gemini_model,
            timeout=self.cfg.gemini_timeout,
        )
        self._drift = DriftTracker(
            path=self.cfg.drift_history_path,
            window=self.cfg.drift_window,
        )
        self._log_lock = threading.Lock()

    def evaluate(self, prompt: str, query_id: Optional[str] = None) -> SurvivalResult:
        """
        Full S(x) evaluation pipeline.
        1. Get baseline response f(x)
        2. Perturb → compute κ and ΔL
        3. Context-vary → compute ΔG
        4. Compute S, A, decision
        5. Drift update
        6. Log
        """
        t_start = time.monotonic()
        timestamp = datetime.now(timezone.utc).isoformat()

        if query_id is None:
            query_id = hashlib.sha256(
                f"{timestamp}:{prompt}".encode()
            ).hexdigest()[:16]

        logger.info("[%s] Starting survival eval for prompt: %.80s…", query_id, prompt)

        # ── Step 1: baseline ──────────────────────────────────────────
        baseline_text = self._client.generate(prompt)
        try:
            baseline_vec = self._client.embed(baseline_text)
        except Exception:
            baseline_vec = None
            logger.warning("[%s] Embedding unavailable, falling back to Jaccard", query_id)

        # ── Step 2: κ and ΔL ─────────────────────────────────────────
        kappa, delta_L = _compute_kappa_and_delta_L(
            prompt, baseline_text, baseline_vec, self._client, self.cfg
        )

        # ── Step 3: ΔG ───────────────────────────────────────────────
        delta_G = _compute_delta_G(prompt, self._client, self.cfg)

        # ── Step 4: scalar metrics ────────────────────────────────────
        S = _survival_scalar(kappa, delta_L, delta_G, self.cfg)
        A = _amplification(kappa, self.cfg.epsilon_u)
        decision = _decision(S, self.cfg)

        # ── Step 5: drift ─────────────────────────────────────────────
        S_dot, drift_warning = self._drift.update(timestamp, S)

        latency_ms = round((time.monotonic() - t_start) * 1000, 1)

        result = SurvivalResult(
            query_id=query_id,
            prompt=prompt,
            baseline_response=baseline_text,
            kappa=round(kappa, 6),
            delta_L=round(delta_L, 6),
            delta_G=round(delta_G, 6),
            S=round(S, 6),
            A=round(A, 4),
            decision=decision,
            S_dot=round(S_dot, 6) if S_dot is not None else None,
            drift_warning=drift_warning,
            timestamp=timestamp,
            config_snapshot={
                "lambda1": self.cfg.lambda1,
                "lambda2": self.cfg.lambda2,
                "epsilon_u": self.cfg.epsilon_u,
                "tau_high": self.cfg.tau_high,
                "tau_low": self.cfg.tau_low,
                "n_perturbations": self.cfg.n_perturbations,
                "n_contexts": self.cfg.n_contexts,
                "model": self.cfg.gemini_model,
            },
            latency_ms=latency_ms,
        )

        # ── Step 6: log ───────────────────────────────────────────────
        self._append_log(result)

        logger.info(
            "[%s] S=%.4f A=%.2f decision=%s drift=%s (%.0fms)",
            query_id, S, A, decision,
            f"{S_dot:+.4f}" if S_dot is not None else "n/a",
            latency_ms,
        )

        return result

    def _append_log(self, result: SurvivalResult):
        with self._log_lock:
            with open(self.cfg.survival_log_path, "a") as f:
                f.write(json.dumps(result.to_dict()) + "\n")

    def drift_summary(self, n: int = 20) -> dict:
        return {
            "recent": self._drift.recent(n),
            "trend": self._drift.trend(),
        }

    def recent_evaluations(self, n: int = 20) -> list[dict]:
        """Read last n entries from survival_log.jsonl."""
        p = Path(self.cfg.survival_log_path)
        if not p.exists():
            return []
        lines = p.read_text().strip().splitlines()
        results = []
        for line in lines[-n:]:
            try:
                results.append(json.loads(line))
            except Exception:
                pass
        return list(reversed(results))
